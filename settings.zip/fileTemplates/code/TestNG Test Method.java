@org.testng.annotations.Test
public void ${NAME}() {
  ${BODY}
}