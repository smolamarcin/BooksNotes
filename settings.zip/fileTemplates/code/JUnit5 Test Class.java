import static org.junit.jupiter.api.Assertions.*;
#parse("File Header.java")
public class ${NAME} {
  ${BODY}
}